# Lab 6: Motion Planning

## Video Link
https://youtu.be/34ps_5LvWOY
